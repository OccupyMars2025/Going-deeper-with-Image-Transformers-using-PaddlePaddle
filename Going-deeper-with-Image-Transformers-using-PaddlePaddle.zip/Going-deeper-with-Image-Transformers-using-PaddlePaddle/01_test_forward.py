import torch
import paddle
import numpy as np
from reprod_log import ReprodDiffHelper
from reprod_log import ReprodLogger

# from mobilenetv3_paddle.paddlevision.models import mobilenet_v3_small as mv3_small_paddle
# from mobilenetv3_ref.torchvision.models import mobilenet_v3_small as mv3_small_torch
from CaiT_torch.cait_models import cait_XXS24_224 as cait_XXS24_torch
from CaiT_paddle.cait_models import cait_XXS24_224 as cait_XXS24_paddle


def test_forward():
    device = "cpu"  # you can also set it as "cpu"
    torch_device = torch.device("cuda:0" if device == "gpu" else "cpu")
    paddle.set_device(device)

    # load paddle model
    # paddle_model = mv3_small_paddle()
    paddle_model = cait_XXS24_paddle(pretrained=False)
    paddle_model.eval()
    paddle_state_dict = paddle.load("./data/cait_XXS24_224.pdparams")
    paddle_model.set_state_dict(paddle_state_dict)

    # load torch model
    torch_model = cait_XXS24_torch(pretrained=False)
    torch_model.eval()
    torch_state_dict = torch.load("./data/cait_XXS24_224.pth")
    torch_model.load_state_dict(torch_state_dict)

    torch_model.to(torch_device)

    # load data
    inputs = np.load("./data/fake_data.npy")

    # save the paddle output
    reprod_logger = ReprodLogger()
    paddle_out = paddle_model(paddle.to_tensor(inputs, dtype="float32"))
    reprod_logger.add("logits", paddle_out.cpu().detach().numpy())
    reprod_logger.save("./result/forward_paddle.npy")

    # save the torch output
    torch_out = torch_model(
        torch.tensor(
            inputs, dtype=torch.float32).to(torch_device))
    reprod_logger.add("logits", torch_out.cpu().detach().numpy())
    reprod_logger.save("./result/forward_torch.npy")


if __name__ == "__main__":
    test_forward()

    # load data
    diff_helper = ReprodDiffHelper()
    torch_info = diff_helper.load_info("./result/forward_torch.npy")
    paddle_info = diff_helper.load_info("./result/forward_paddle.npy")
    # print(type(torch_info), torch_info.keys())
    # for k in torch_info:
    #     print(k, type(torch_info[k]), torch_info[k].shape)
    # exit()

    # compare result and produce log
    diff_helper.compare_info(torch_info, paddle_info)
    diff_helper.report(
        path="./result/log/forward_diff.log",
        diff_threshold=1e-5,
        diff_method='all'
    )
