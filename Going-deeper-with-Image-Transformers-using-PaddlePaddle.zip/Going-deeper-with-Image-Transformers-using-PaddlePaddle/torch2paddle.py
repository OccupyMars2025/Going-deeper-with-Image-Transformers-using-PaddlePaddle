import torch
import paddle

from CaiT_torch.cait_models import cait_XXS24_224 as cait_XXS24_torch
from CaiT_paddle.cait_models import cait_XXS24_224 as cait_XXS24_paddle


def torch2paddle():
    """
    store state_dict to the path paddle_path
    in the form  {str: np.ndarray} which will be
    loaded directly by paddle.load()
    """
    torch_path = "./data/cait_XXS24_224.pth"
    paddle_path = "./data/cait_XXS24_224.pdparams"

    torch_model = cait_XXS24_torch(pretrained=True)
    torch_model.eval()
    paddle_model = cait_XXS24_paddle(pretrained=False)
    paddle_model.eval()


    #######  start: this part shows that the keys of the two models'
    #######  state_dict are totally matched
    print("keys that are IN  torch_model.state_dict()\n"
          "             NOT IN paddle_model.state_dict():")
    for k in torch_model.state_dict().keys():
        if k not in paddle_model.state_dict().keys():
            print(k)
    print(20*'=')

    print("keys that are IN  paddle_model.state_dict()\n"
          "             NOT IN torch_model.state_dict():")
    for k in paddle_model.state_dict().keys():
        if k not in torch_model.state_dict().keys():
            print(k)
    print(20*'=')
    #######  end: this part shows that the keys of the two models'
    #######  state_dict are totally matched

    torch.save(torch_model.state_dict(), torch_path)
    torch_state_dict = torch.load(torch_path)
    paddle_state_dict = {}
    for k in torch_state_dict:
        v = torch_state_dict[k].detach().cpu().numpy()
        if "weight" in k and v.ndim == 2:
            permutation = [1, 0]
            print(
                f"name: {k}, original shape: {v.shape}, new shape: {v.transpose(permutation).shape}"
            )
            v = v.transpose(permutation)
        paddle_state_dict[k] = v
    paddle.save(paddle_state_dict, paddle_path)

    # # the following code is the official code
    # fc_names = ["classifier"]
    # paddle_state_dict = {}
    # for k in torch_state_dict:
    #     if "num_batches_tracked" in k:
    #         continue
    #     v = torch_state_dict[k].detach().cpu().numpy()
    #     flag = [i in k for i in fc_names]
    #     # if any(flag) and "weight" in k:  # ignore bias
    #     if "weight" in k and v.ndim == 2:
    #         # permutation = [1, 0] + list(range(2, v.ndim))
    #         permutation = [1, 0]
    #         print(
    #             f"name: {k}, original shape: {v.shape}, new shape: {v.transpose(permutation).shape}"
    #         )
    #         v = v.transpose(permutation)
    #     k = k.replace("running_var", "_variance")
    #     k = k.replace("running_mean", "_mean")
    #     # if k not in model_state_dict:
    #     if False:
    #         print(k)
    #     else:
    #         paddle_state_dict[k] = v
    # paddle.save(paddle_state_dict, paddle_path)


if __name__ == "__main__":
    torch2paddle()
