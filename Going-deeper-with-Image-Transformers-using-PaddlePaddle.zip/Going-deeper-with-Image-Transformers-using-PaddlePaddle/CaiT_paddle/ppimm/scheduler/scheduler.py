import warnings
from typing import Dict, Any

# import torch
import paddle

# # pytorch version
# class Scheduler:
#     """ Parameter Scheduler Base Class
#     A scheduler base class that can be used to schedule any optimizer parameter groups.
#
#     Unlike the builtin PyTorch schedulers, this is intended to be consistently called
#     * At the END of each epoch, before incrementing the epoch count, to calculate next epoch's value
#     * At the END of each optimizer update, after incrementing the update count, to calculate next update's value
#
#     The schedulers built on this should try to remain as stateless as possible (for simplicity).
#
#     This family of schedulers is attempting to avoid the confusion of the meaning of 'last_epoch'
#     and -1 values for special behaviour. All epoch and update counts must be tracked in the training
#     code and explicitly passed in to the schedulers on the corresponding step or step_update call.
#
#     Based on ideas from:
#      * https://github.com/pytorch/fairseq/tree/master/fairseq/optim/lr_scheduler
#      * https://github.com/allenai/allennlp/tree/master/allennlp/training/learning_rate_schedulers
#     """
#
#     def __init__(self,
#                  optimizer: torch.optim.Optimizer,
#                  param_group_field: str,
#                  noise_range_t=None,
#                  noise_type='normal',
#                  noise_pct=0.67,
#                  noise_std=1.0,
#                  noise_seed=None,
#                  initialize: bool = True) -> None:
#         # self.optimizer = optimizer
#         self.param_group_field = param_group_field
#         self._initial_param_group_field = f"initial_{param_group_field}"
#         if initialize:
#             for i, group in enumerate(self.optimizer.param_groups):
#                 if param_group_field not in group:
#                     raise KeyError(f"{param_group_field} missing from param_groups[{i}]")
#                 group.setdefault(self._initial_param_group_field, group[param_group_field])
#         else:
#             for i, group in enumerate(self.optimizer.param_groups):
#                 if self._initial_param_group_field not in group:
#                     raise KeyError(f"{self._initial_param_group_field} missing from param_groups[{i}]")
#         self.base_values = [group[self._initial_param_group_field] for group in self.optimizer.param_groups]
#         self.metric = None  # any point to having this for all?
#         self.noise_range_t = noise_range_t
#         self.noise_pct = noise_pct
#         self.noise_type = noise_type
#         self.noise_std = noise_std
#         self.noise_seed = noise_seed if noise_seed is not None else 42
#         self.update_groups(self.base_values)
#
#     def state_dict(self) -> Dict[str, Any]:
#         return {key: value for key, value in self.__dict__.items() if key != 'optimizer'}
#
#     def load_state_dict(self, state_dict: Dict[str, Any]) -> None:
#         self.__dict__.update(state_dict)
#
#     def get_epoch_values(self, epoch: int):
#         return None
#
#     def get_update_values(self, num_updates: int):
#         return None
#
#     def step(self, epoch: int, metric: float = None) -> None:
#         self.metric = metric
#         values = self.get_epoch_values(epoch)
#         if values is not None:
#             values = self._add_noise(values, epoch)
#             self.update_groups(values)
#
#     def step_update(self, num_updates: int, metric: float = None):
#         self.metric = metric
#         values = self.get_update_values(num_updates)
#         if values is not None:
#             values = self._add_noise(values, num_updates)
#             self.update_groups(values)
#
#     def update_groups(self, values):
#         if not isinstance(values, (list, tuple)):
#             values = [values] * len(self.optimizer.param_groups)
#         for param_group, value in zip(self.optimizer.param_groups, values):
#             param_group[self.param_group_field] = value
#
#     def _add_noise(self, lrs, t):
#         if self.noise_range_t is not None:
#             if isinstance(self.noise_range_t, (list, tuple)):
#                 apply_noise = self.noise_range_t[0] <= t < self.noise_range_t[1]
#             else:
#                 apply_noise = t >= self.noise_range_t
#             if apply_noise:
#                 g = torch.Generator()
#                 g.manual_seed(self.noise_seed + t)
#                 if self.noise_type == 'normal':
#                     while True:
#                         # resample if noise out of percent limit, brute force but shouldn't spin much
#                         noise = torch.randn(1, generator=g).item()
#                         if abs(noise) < self.noise_pct:
#                             break
#                 else:
#                     noise = 2 * (torch.rand(1, generator=g).item() - 0.5) * self.noise_pct
#                 lrs = [v + v * noise for v in lrs]
#         return lrs


# paddlepaddle version
class Scheduler:
    """ Parameter Scheduler Base Class
    A scheduler base class that can be used to schedule any optimizer parameter groups.

    Unlike the builtin PyTorch schedulers, this is intended to be consistently called
    * At the END of each epoch, before incrementing the epoch count, to calculate next epoch's value
    * At the END of each optimizer update, after incrementing the update count, to calculate next update's value

    The schedulers built on this should try to remain as stateless as possible (for simplicity).

    This family of schedulers is attempting to avoid the confusion of the meaning of 'last_epoch'
    and -1 values for special behaviour. All epoch and update counts must be tracked in the training
    code and explicitly passed in to the schedulers on the corresponding step or step_update call.

    Based on ideas from:
     * https://github.com/pytorch/fairseq/tree/master/fairseq/optim/lr_scheduler
     * https://github.com/allenai/allennlp/tree/master/allennlp/training/learning_rate_schedulers
    """

    def __init__(self,
                 # optimizer: torch.optim.Optimizer,
                 # param_group_field: str,
                 learning_rate=0.1, last_epoch=-1, verbose=False,
                 noise_range_t=None,
                 noise_type='normal',
                 noise_pct=0.67,
                 noise_std=1.0,
                 noise_seed=None,
                 initialize: bool = True) -> None:
        # self.optimizer = optimizer
        # self.param_group_field = param_group_field
        # self._initial_param_group_field = f"initial_{param_group_field}"
        # if initialize:
        #     for i, group in enumerate(self.optimizer.param_groups):
        #         if param_group_field not in group:
        #             raise KeyError(f"{param_group_field} missing from param_groups[{i}]")
        #         group.setdefault(self._initial_param_group_field, group[param_group_field])
        # else:
        #     for i, group in enumerate(self.optimizer.param_groups):
        #         if self._initial_param_group_field not in group:
        #             raise KeyError(f"{self._initial_param_group_field} missing from param_groups[{i}]")
        # self.base_values = [group[self._initial_param_group_field] for group in self.optimizer.param_groups]
        # self.metric = None  # any point to having this for all?
        self.noise_range_t = noise_range_t
        self.noise_pct = noise_pct
        self.noise_type = noise_type
        self.noise_std = noise_std
        self.noise_seed = noise_seed if noise_seed is not None else 42
        # self.update_groups(self.base_values)
        if not isinstance(learning_rate, (float, int)):
            raise TypeError(
                "The type of learning rate must be float, but received {}".
                format(type(learning_rate)))
        self.base_lr = float(learning_rate)
        self.last_lr = float(learning_rate)
        self.last_epoch = last_epoch
        self.verbose = verbose


    # def state_dict(self) -> Dict[str, Any]:
    #     return {key: value for key, value in self.__dict__.items() if key != 'optimizer'}
    #
    # def load_state_dict(self, state_dict: Dict[str, Any]) -> None:
    #     self.__dict__.update(state_dict)
    def state_dict(self):
        """

        Returns the state of the scheduler as a :class:`dict`.

        It is a subset of ``self.__dict__`` .
        """
        self.state_keys()
        state_dict = {}
        for key in self.keys:
            if key not in self.__dict__:
                continue
            value = self.__dict__[key]
            if isinstance(value, paddle.Tensor):
                assert value.shape == [
                    1
                ], "shape of Tensor in state_dict must be [1] {}".format(
                    value.shape)
                value = value.numpy()[0]
            state_dict[key] = value

        return state_dict

    # For those subclass who overload LRScheduler, "last_epoch, last_lr" will be saved by default.
    # (Note): you can change it for your subclass.
    def state_keys(self):
        """

        For those subclass who overload ``LRScheduler`` (Base Class). Acquiescently, "last_epoch, last_lr" will be saved by ``self.keys = ['last_epoch', 'last_lr']`` .

        ``last_epoch`` is the current epoch num, and ``last_lr`` is the current learning rate.

        If you want to change the default behavior, you should have a custom implementation of ``_state_keys()`` to redefine ``self.keys`` .

        """
        self.keys = ['last_epoch', 'last_lr']

    def set_state_dict(self, state_dict):
        """

        Loads the schedulers state.
        """
        self.state_keys()
        for key in self.keys:
            if key in state_dict:
                self.__dict__[key] = state_dict[key]
            else:
                raise RuntimeError(
                    "Please check whether state_dict is correct for optimizer. Can't find [ {} ] in state_dict".
                    format(key))
        if len(state_dict) > len(self.keys):
            warnings.warn(
                "There are some unused values in state_dict. Maybe the optimizer have different 'LearningRateDecay' when invoking state_dict and set_dict"
            )

    # def get_epoch_values(self, epoch: int):
    #     return None
    #
    # def get_update_values(self, num_updates: int):
    #     return None
    def get_lr(self):
        """

        For those subclass who overload ``LRScheduler`` (Base Class), User should have a custom implementation of ``get_lr()`` .

        Otherwise, an ``NotImplementedError`` exception will be thrown.
        """
        # calculate by python float
        raise NotImplementedError

    # def step(self, epoch: int, metric: float = None) -> None:
    #     self.metric = metric
    #     values = self.get_epoch_values(epoch)
    #     if values is not None:
    #         values = self._add_noise(values, epoch)
    #         self.update_groups(values)
    def step(self, epoch=None):
        """

        ``step`` should be called after ``optimizer.step`` . It will update the learning rate in optimizer according to current ``epoch`` .
        The new learning rate will take effect on next ``optimizer.step`` .

        Args:
            epoch (int, None): specify current epoch. Default: None. Auto-increment from last_epoch=-1.

        Returns:
            None

        """
        if epoch is None:
            self.last_epoch += 1
            self.last_lr = self.get_lr()
        else:
            self.last_epoch = epoch
            if hasattr(self, "_get_closed_form_lr"):
                self.last_lr = self._get_closed_form_lr()
            else:
                self.last_lr = self.get_lr()
        self.last_lr = self._add_noise(self.last_lr, epoch)
        if self.verbose:
            print('Epoch {}: {} set learning rate to {}.'.format(
                self.last_epoch, self.__class__.__name__, self.last_lr))

    # def step_update(self, num_updates: int, metric: float = None):
    #     self.metric = metric
    #     values = self.get_update_values(num_updates)
    #     if values is not None:
    #         values = self._add_noise(values, num_updates)
    #         self.update_groups(values)
    #
    # def update_groups(self, values):
    #     if not isinstance(values, (list, tuple)):
    #         values = [values] * len(self.optimizer.param_groups)
    #     for param_group, value in zip(self.optimizer.param_groups, values):
    #         param_group[self.param_group_field] = value

    def _add_noise(self, lr, t):
        if self.noise_range_t is not None:
            if isinstance(self.noise_range_t, (list, tuple)):
                apply_noise = self.noise_range_t[0] <= t < self.noise_range_t[1]
            else:
                apply_noise = t >= self.noise_range_t
            if apply_noise:
                # g = torch.Generator()
                # g.manual_seed(self.noise_seed + t)
                paddle.seed(self.noise_seed + t)
                if self.noise_type == 'normal':
                    while True:
                        # resample if noise out of percent limit, brute force but shouldn't spin much
                        # noise = torch.randn(1, generator=g).item()
                        noise = paddle.randn(1).item()
                        if abs(noise) < self.noise_pct:
                            break
                else:
                    noise = 2 * (paddle.rand(1).item() - 0.5) * self.noise_pct
                # lrs = [v + v * noise for v in lrs]
                lr = lr + lr * noise
        return lr

