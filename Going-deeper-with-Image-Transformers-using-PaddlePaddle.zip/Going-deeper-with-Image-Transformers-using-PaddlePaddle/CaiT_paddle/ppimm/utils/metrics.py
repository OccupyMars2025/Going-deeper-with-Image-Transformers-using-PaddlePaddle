""" Eval metrics and related

Hacked together by / Copyright 2020 Ross Wightman
"""


class AverageMeter:
    """Computes and stores the average and current value"""
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def accuracy(output, target, topk=(1,)):
    """Computes the accuracy over the k top predictions for the specified values of k"""
    # print("paddle output:", output)
    # print("paddle targer:", target)
    # return
    maxk = max(topk)
    # batch_size = target.size(0)
    batch_size = target.shape[0]
    _, pred = output.topk(maxk, 1, True, True)
    pred = pred.t()
    # correct = pred.eq(target.reshape(1, -1).expand_as(pred))
    # print(pred)
    # print(target.reshape([1, -1]).expand_as(pred))
    # exit()
    correct = pred == target.reshape([1, -1]).expand_as(pred)
    # print(correct)
    # exit()
    # return [correct[:k].reshape(-1).float().sum(0) * 100. / batch_size for k in topk]
    return [correct[:k].sum() * 100. / batch_size for k in topk]

#
# if __name__ == "__main__":
#     import paddle
#     output = paddle.rand([16, 1000])
#     target = paddle.randint(low=0, high=16, shape=[16])
#     # print(output)
#     # print(target)
#     # exit()
#     topk = (1, 5)
#     maxk = max(topk)
#     # batch_size = target.size(0)
#     batch_size = target.shape[0]
#     _, pred = output.topk(maxk, 1, True, True)
#     # print(pred)
#     # exit()
#     pred = pred.t()
#     # print(pred)
#     # exit()
#     # correct = pred.eq(target.reshape(1, -1).expand_as(pred))
#     # print(target.reshape([1, -1]).expand_as(pred))
#     # exit()
#     correct = pred.equal(target.reshape([1, -1]).expand_as(pred))
#     # print(correct)
#     # exit()
#     print(correct[:5].sum())
#     exit()
#     result = [correct[:k].reshape([-1]).float().sum(0) * 100. / batch_size for k in topk]
#     print(result)