import paddle

import paddle.nn.functional as F

F.softmax_with_cross_entropy
