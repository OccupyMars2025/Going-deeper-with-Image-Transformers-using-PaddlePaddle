import paddle


class MyLayer(paddle.nn.Layer):
    """

    """
    def __init__(self):
        super(MyLayer, self).__init__()
        self.param_1 = self.create_parameter(
            shape=[1, 1, 3],
            default_initializer=paddle.nn.initializer.Constant(value=1)
        )
        paddle.nn.initializer.Constant(value=100)(self.param_1)
        paddle.nn.initializer.TruncatedNormal()(self.param_1)

        self.param_2 = self.param_1.expand([4, -1, -1])
        print("self.param_2:", self.param_2)

    def forward(self, x):
        return x * self.param_1

if __name__ == "__main__":
    my_layer = MyLayer()
    for name, param in my_layer.named_parameters():
        print(name, param)

# x_np = np.ones(shape=[2, 3])
#
# x_paddle = paddle.to_tensor(x_np)
# y_paddle = paddle.nn.initializer.TruncatedNormal()(x_paddle)
# print(x_paddle, y_paddle, sep='\n')

# import paddle
# import torch
# import numpy as np
#
# torch.nn.init.trunc_normal_()
# x_np = np.random.uniform(-100, 100, size=[2, 3])
# x_torch = torch.as_tensor(x_np)
# x_paddle = paddle.to_tensor(x_np)
#
# y_torch = x_torch.erfinv_()
# y_paddle = x_paddle.erfinv_()
#
# print(x_torch)
# print(y_torch)
# # x_paddle = paddle.ones([2, 3])
# # y_paddle = x_paddle.uniform_(-3, 100)
# # print(x_paddle)
# # print(y_paddle)


# import torch
# import paddle
#
#
# w = torch.empty(2, 3)
# torch.nn.init.trunc_normal_(w)
# x_paddle = paddle.empty([2, 3])
# paddle.nn.initializer.normal
# print(w)

# import paddle
# import torch.nn.init
#
# paddle.nn.initializer.TruncatedNormal(std=0.2)
# paddle.nn.initializer.
# torch.nn.init.trunc_normal_()

# import paddle
#
# x_paddle = paddle.uniform(shape=[2, 3, 4, 5], min=-100, max=100)
# y_paddle = x_paddle.flatten(1)
# y_paddle_2 = paddle.flatten(x_paddle, start_axis=1)
# print(x_paddle.shape, y_paddle.shape, y_paddle_2.shape, sep='\n')
# print(10*'#')
# print((y_paddle == y_paddle_2).all())


# import paddle
# import torch
# import numpy as np
#
# x_np = np.random.uniform(-100, 100, [2, 3])
# x_torch = torch.as_tensor(x_np)
# x_paddle = paddle.to_tensor(x_np)
#
# # y_torch = x_torch.softmax(-1)
# # y_paddle = paddle.nn.functional.softmax(x_paddle, -1)
# # print(np.allclose(y_torch.numpy(), y_paddle.numpy()))
#
#
# # y_torch = torch.nn.GELU()(x_torch)
# # y_paddle = paddle.nn.GELU()(x_paddle)
# # print(np.allclose(y_torch.numpy(), y_paddle.numpy()))
#
# # print(x_torch.shape, x_torch.ndim)
# # print(x_paddle.shape, x_paddle.ndim)
#
# # shape = [2, 3]
# # y_torch = torch.rand(shape, dtype=x_torch.dtype, device=x_torch.device)
# # print(y_torch, y_torch.requires_grad, y_torch.device, sep='\n')
# # print(10*'#')
# # y_paddle = paddle.rand(shape, dtype=x_paddle.dtype)
# # y_paddle = paddle.to_tensor(y_paddle, place=x_paddle.place)
# # print(y_paddle, y_paddle.stop_gradient, y_paddle.place, sep='\n')
#
# print(x_torch)
# x_torch.floor_()
# print(x_torch)
#
# print(10*'#')
# print(x_paddle)
# x_paddle.floor_()
# print(x_paddle)
#

#
# import paddle
#
# class MyLayer(paddle.nn.Layer):
#     """
#
#     """
#     def __init__(self):
#         super().__init__()
#         self.gamma_1 = self.create_parameter(shape=[2, 3],
#                                              is_bias=False,
#                                              default_initializer=paddle.nn.initializer.Constant(1.7))
#     def forward(self, x):
#         return x * self.gamma_1
#
# if __name__ == "__main__":
#     my_layer = MyLayer()
#     for name, param in my_layer.named_parameters():
#         print(name, param)
#
# from itertools import repeat
# # from torch._six import container_abcs
# from collections.abc import Iterable
#
# print(isinstance([2, 3], Iterable))
# print(isinstance(3, Iterable))
